<?php require_once'header.php'; 
require_once 'slider.php';
$urunekle=$conn->prepare("SELECT * from urunler");
$urunekle-> execute();
error_reporting(0);
?>

<div class="site-section site-section-sm bg-light">
  <div class="container">
    <?php  while ($cek=$urunekle-> fetch(PDO::FETCH_ASSOC)) {   ?>
          <div class="row mb-5">
          <div class="col-md-12">

            <div class="property-entry horizontal d-lg-flex">

              <a href="detay.php?id=<?php echo $cek['id']?>" class="property-thumbnail h-100">
                <div class="offer-type-wrap">
               
                  <span class="offer-type bg-success" ><?php echo $cek['durum'];?></span>
                </div>
                <img style="width: 800px; height: 400px;" src="panel/resimler/<?php echo $cek['resim'];?>" alt="Image" class="img-fluid">
              </a>

              <div class="p-4 property-body">
                <a href="#" class="property-favorite"><span class="icon-heart-o"></span></a>
                <h2 class="property-title"><a href="#"><?php echo $cek['adi'];?></a></h2>
                <span class="property-location d-block mb-3" ><span class="property-icon icon-room"></span>  <?php echo $cek['adres'];?></span>
                <strong class="property-price text-primary mb-3 d-block text-success"><?php echo $cek['fiyat'];?></strong>
                <p><?php echo $cek['aciklama'];?></p>
          
              </div>

            </div>

          </div>
        </div>
       <?php }?>
  
</div>
</div>





<?php require'footer.php';?>